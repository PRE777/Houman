<template>
  <div class="main">
    <navbar></navbar>
    <el-container>
      <el-aside width="200px">
        <el-tree
          :data="constructData"
          :props="defaultProps"
          accordion
          @node-click="handleNodeClick"
        ></el-tree>
      </el-aside>
      <el-main>
          <el-tabs v-model="activeName" type="card">
         <el-tab-pane v-for="item in personnels" :key="item.name" :label="item.name" :name="item.activeName">
              <!-- <el-table fixed :data="writingInfos">
                <el-table-column
                  v-for="item in writingInfoColums"
                  :key="item.key"
                  :prop="item.key"
                  :label="item.title"
                  width="110"
                ></el-table-column>
          </el-tabs> -->
      </el-main>
    </el-container>
    <el-footer>Footer</el-footer>
  </div>
</template>

<script>
import Navbar from "@/views/Dashboard/Navbar.vue";

var treeData = [];
export default {
  name: "dashboard",
  components: { Navbar },
  data() {
    return {
      user: "",
      personnels:[{name:"军官",activeName:"1"},{name:"士兵",activeName:"2"},{name:"文职人员",activeName:"3"}],
      constructData: treeData, // 树形结构数据
      defaultProps: {
        children: "children",
        label: "label"
      },
      activeName:"1",
    };
  },
  created: function() {
    setTimeout(() => {
      treeData = require("./unitData.json").unitData;
      this.constructData = treeData;
    }, 2000);
  },
  methods: {
    handleNodeClick(data) {
        console.log(data.id);
    }
  }
};
</script>

<style scoped>
.main {
  display: flex;
  height: 100%;
  flex-direction: column;
}
.el-header,
.el-footer {
  background-color: #b3c0d1;
  color: #333;
  text-align: center;
  line-height: 60px;
}
.el-aside {
  background-color: #d3dce6;
  color: #333;
  text-align: center;
  /* line-height: 200px; */
}

.el-main {
  background-color: #e9eef3;
  color: #333;
  text-align: center;
  line-height: 160px;
}

body > .el-container {
  flex: 1;
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>